package com.kaynaak.rest.common;

/**
 * Author: Nguyen Duc Cuong
 * Create date: Friday, 9/28/2018 11:37 AM
 * Email: cuongnd@vega.com.vn
 * Project: mychef
 */
public class UserRoleConstant {

    public static String CUSTOMER_ROLE = "Customer";
    public static String ADMIN_ROLE = "Admin";

}

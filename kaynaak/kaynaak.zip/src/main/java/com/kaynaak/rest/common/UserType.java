package com.kaynaak.rest.common;

/**
 * Author: Nguyen Duc Cuong
 * Create date: Friday, 12/7/2018 4:36 PM
 * Email: cuongnd@vega.com.vn
 * Project: rest
 */
public class UserType {

    public static final String BAKER_USER_TYPE = "baker";
    public static final String CUSTOMER_USER_TYPE = "customer";

}

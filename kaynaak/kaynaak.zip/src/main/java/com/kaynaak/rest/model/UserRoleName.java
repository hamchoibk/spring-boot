package com.kaynaak.rest.model;

public enum UserRoleName {
    ROLE_CUSTOMER,
    ROLE_CHEF
}

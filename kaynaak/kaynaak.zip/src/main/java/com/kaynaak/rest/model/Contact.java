package com.kaynaak.rest.model;

/**
 * Author: Nguyen Duc Cuong
 * Create date: Friday, 11/30/2018 11:39 AM
 * Email: cuongnd@vega.com.vn
 * Project: rest
 */
public class Contact {

    private String action;
    private String number;
}

# Mychefv1
This is new version of backend development project

## Techs required

- Java 8
- Mongodb installed
- Spring boot, Security
- Restful API

## Tools

We are using the very popular tool 
- Robo 3T
- Intellji IDE
